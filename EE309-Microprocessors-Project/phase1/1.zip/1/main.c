#include <at89c5131A.h>
#include "spi.h"
#include "mcp4921.h"

/* NCO: Fs = 16384 Hz, f = 410 Hz, delta = 65536 * 410 / 16384 = 1640
   Timer 0 mode 1 reload: 65536 - 122 = 65414 = 0xFF86 */
#define TH0_RELOAD   0xFF
#define TL0_RELOAD   0x86
#define PHASE_INC    1640u

sfr CKCON_REG = 0x8F;

code unsigned char sine32[32] = {
    128, 153, 177, 199, 218, 234, 245, 253,
    255, 253, 245, 234, 218, 199, 177, 153,
    128, 103,  79,  57,  38,  22,  11,   3,
      1,   3,  11,  22,  38,  57,  79, 103
};

volatile unsigned int phase = 0;

void timer0_isr(void) interrupt 1 {
    unsigned char idx;

    TH0 = TH0_RELOAD;
    TL0 = TL0_RELOAD;

    phase += PHASE_INC;
    idx = ((unsigned char)(phase >> 8)) >> 3;
    dac_write((unsigned int)sine32[idx] << 4);
}

void main(void) {
    CKCON_REG &= ~0x01;        /* ensure standard timer clock (XTAL/12) */

    spi_init();
    dac_init();

    TMOD = (TMOD & 0xF0) | 0x01;
    TH0  = TH0_RELOAD;
    TL0  = TL0_RELOAD;
    ET0  = 1;
    EA   = 1;
    TR0  = 1;

    while (1);
}
